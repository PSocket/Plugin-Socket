//The code isn't very complex now and that is because I plan on redoing this to work with another compiler, because most of the code will be redone from scratch anyway only the minimum is here, this is only a testing version.
//This release has only the bare minimum as, right now this is a quick way to have a functioning demo.
//Plan on releasing a Feature complete BETA on or before February 2018 and possibly some more ALPHA versions between until then I will discuss various things such as the best layout for PARAMETERS.INI and test out various things with the ALPHA versions and possibly collaborate.
//Planning versions for Flash,Unity & Java, it is worth noting some flash content cannot be loaded outside a web browser thus will not run in a Projector or this program in its current stage one of the goals of this project is to have those running and potentially archive them See Readme.txt for more details!
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "inifiles.hpp"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ShockwaveFlashObjects_TLB"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm1::FormCreate(TObject *Sender)
{
//"first" - Anon
Plugin->Top=Button1->Tag ;
	TIniFile *inifile = new TIniFile("./PARAMETERS.INI");
    //Placeholders for miscellaneous input
	PAR1->Text = inifile->ReadString("PLUGIN 1", "PARAMETER1", "");
    PAR2->Text = inifile->ReadString("PLUGIN 1", "PARAMETER2", "");
    PAR3->Text = inifile->ReadString("PLUGIN 1", "PARAMETER3", "");
    PAR4->Text = inifile->ReadString("PLUGIN 1", "PARAMETER4", "");
    //Placeholders for miscellaneous input
    // input
    Plugin -> Movie= inifile->ReadString("PLUGIN 1", "FILE", "");
    INPT -> Text  = inifile->ReadString("PLUGIN 1", "WIDTH", "");
    Plugin -> Width = StrToInt(INPT -> Text);
    INPT -> Text  = inifile->ReadString("PLUGIN 1", "HEIGHT", "");
    Plugin -> Height = StrToInt(INPT -> Text);
    // input
	if (inifile)
		delete inifile;
        Plugin->Top=Button1->Tag ;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::VClick(TObject *Sender)
{
Plugin->Top=V->Tag ;
V -> Visible=False;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
Plugin->Top=Button1->Tag ;
V -> Visible=True;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
 Plugin -> Width = StrToInt(SCLW -> Text);
 Plugin -> Height = StrToInt(SCLH -> Text);
}
//---------------------------------------------------------------------------

