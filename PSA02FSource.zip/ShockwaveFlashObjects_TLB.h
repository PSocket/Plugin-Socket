// ************************************************************************ //
// WARNING                                                                  //
// -------                                                                  //
// The types declared in this file were generated from data read from a     //
// Type Library. If this type library is explicitly or indirectly (via      //
// another type library referring to this type library) re-imported, or the //
// 'Refresh' command of the Type Library Editor activated while editing the //
// Type Library, the contents of this file will be regenerated and all      //
// manual modifications will be lost.                                       //
// ************************************************************************ //

/* File generated on 8/28/17 9:00:27 PM from Type Library described below. */

// ************************************************************************ //
// Type Lib: C:\WINDOWS\SYSTEM\MACROMED\FLASH\SWFLASH.OCX
// IID\LCID: {D27CDB6B-AE6D-11CF-96B8-444553540000}\0
// Helpfile: C:\WINDOWS\SYSTEM\MACROMED\FLASH\SWFLASH.OCX
// DepndLst: 
//   (1) v2.0 stdole, (C:\WINDOWS\SYSTEM\STDOLE2.TLB)
// ************************************************************************ //
#ifndef   __ShockwaveFlashObjects_TLB_h__
#define   __ShockwaveFlashObjects_TLB_h__

#pragma option push -b


#include <sysdefs.h>
#include <utilcls.h>
#include <stdvcl.hpp>
#include <ocxproxy.h>

namespace Shockwaveflashobjects_tlb
{

// *********************************************************************//
// HelpString: Shockwave Flash
// Version:    1.0
// *********************************************************************//


// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:      //
//   Type Libraries     : LIBID_xxxx                                    //
//   CoClasses          : CLSID_xxxx                                    //
//   DISPInterfaces     : DIID_xxxx                                     //
//   Non-DISP interfaces: IID_xxxx                                      //
// *********************************************************************//
DEFINE_GUID(LIBID_ShockwaveFlashObjects, 0xD27CDB6B, 0xAE6D, 0x11CF, 0x96, 0xB8, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00);
DEFINE_GUID(IID_IShockwaveFlash, 0xD27CDB6C, 0xAE6D, 0x11CF, 0x96, 0xB8, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00);
DEFINE_GUID(DIID_DShockwaveFlashEvents, 0xD27CDB6D, 0xAE6D, 0x11CF, 0x96, 0xB8, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00);
DEFINE_GUID(CLSID_ShockwaveFlash, 0xD27CDB6E, 0xAE6D, 0x11CF, 0x96, 0xB8, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00);
DEFINE_GUID(CLSID_FlashProp, 0x1171A62F, 0x05D2, 0x11D1, 0x83, 0xFC, 0x00, 0xA0, 0xC9, 0x08, 0x9C, 0x5A);

// *********************************************************************//
// Forward declaration of interfaces defined in Type Library            //
// *********************************************************************//
interface IShockwaveFlash;
interface DShockwaveFlashEvents;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                     //
// (NOTE: Here we map each CoClass to it's Default Interface            //
// *********************************************************************//
typedef IShockwaveFlash ShockwaveFlash;
typedef IUnknown FlashProp;
// *********************************************************************//
// Interface: IShockwaveFlash
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {D27CDB6C-AE6D-11CF-96B8-444553540000}
// *********************************************************************//
interface IShockwaveFlash : public IDispatch
{
public:
  virtual HRESULT STDMETHODCALLTYPE get_ReadyState(long* thestate/*[out,retval]*/) = 0; // [-525]
  virtual HRESULT STDMETHODCALLTYPE get_TotalFrames(long* numframes/*[out,retval]*/) = 0; // [124]
  virtual HRESULT STDMETHODCALLTYPE get_Playing(VARIANT_BOOL* Playing/*[out,retval]*/) = 0; // [125]
  virtual HRESULT STDMETHODCALLTYPE set_Playing(VARIANT_BOOL Playing/*[in]*/) = 0; // [125]
  virtual HRESULT STDMETHODCALLTYPE get_Quality(int* Quality/*[out,retval]*/) = 0; // [105]
  virtual HRESULT STDMETHODCALLTYPE set_Quality(int Quality/*[in]*/) = 0; // [105]
  virtual HRESULT STDMETHODCALLTYPE get_ScaleMode(int* scale/*[out,retval]*/) = 0; // [120]
  virtual HRESULT STDMETHODCALLTYPE set_ScaleMode(int scale/*[in]*/) = 0; // [120]
  virtual HRESULT STDMETHODCALLTYPE get_AlignMode(int* align/*[out,retval]*/) = 0; // [121]
  virtual HRESULT STDMETHODCALLTYPE set_AlignMode(int align/*[in]*/) = 0; // [121]
  virtual HRESULT STDMETHODCALLTYPE get_BackgroundColor(long* color/*[out,retval]*/) = 0; // [123]
  virtual HRESULT STDMETHODCALLTYPE set_BackgroundColor(long color/*[in]*/) = 0; // [123]
  virtual HRESULT STDMETHODCALLTYPE get_Loop(VARIANT_BOOL* Loop/*[out,retval]*/) = 0; // [106]
  virtual HRESULT STDMETHODCALLTYPE set_Loop(VARIANT_BOOL Loop/*[in]*/) = 0; // [106]
  virtual HRESULT STDMETHODCALLTYPE get_Movie(BSTR* path/*[out,retval]*/) = 0; // [102]
  virtual HRESULT STDMETHODCALLTYPE set_Movie(BSTR path/*[in]*/) = 0; // [102]
  virtual HRESULT STDMETHODCALLTYPE get_FrameNum(long* FrameNum/*[out,retval]*/) = 0; // [107]
  virtual HRESULT STDMETHODCALLTYPE set_FrameNum(long FrameNum/*[in]*/) = 0; // [107]
  virtual HRESULT STDMETHODCALLTYPE SetZoomRect(long left/*[in]*/, long top/*[in]*/, 
                                                long right/*[in]*/, long bottom/*[in]*/) = 0; // [109]
  virtual HRESULT STDMETHODCALLTYPE Zoom(int factor/*[in]*/) = 0; // [118]
  virtual HRESULT STDMETHODCALLTYPE Pan(long x/*[in]*/, long y/*[in]*/, int mode/*[in]*/) = 0; // [119]
  virtual HRESULT STDMETHODCALLTYPE Play(void) = 0; // [112]
  virtual HRESULT STDMETHODCALLTYPE Stop(void) = 0; // [113]
  virtual HRESULT STDMETHODCALLTYPE Back(void) = 0; // [114]
  virtual HRESULT STDMETHODCALLTYPE Forward(void) = 0; // [115]
  virtual HRESULT STDMETHODCALLTYPE Rewind(void) = 0; // [116]
  virtual HRESULT STDMETHODCALLTYPE StopPlay(void) = 0; // [126]
  virtual HRESULT STDMETHODCALLTYPE GotoFrame(long FrameNum/*[in]*/) = 0; // [127]
  virtual HRESULT STDMETHODCALLTYPE CurrentFrame(long* FrameNum/*[out,retval]*/) = 0; // [128]
  virtual HRESULT STDMETHODCALLTYPE IsPlaying(VARIANT_BOOL* Playing/*[out,retval]*/) = 0; // [129]
  virtual HRESULT STDMETHODCALLTYPE PercentLoaded(long* __MIDL_0016/*[out,retval]*/) = 0; // [130]
  virtual HRESULT STDMETHODCALLTYPE FrameLoaded(long FrameNum/*[in]*/, 
                                                VARIANT_BOOL* loaded/*[out,retval]*/) = 0; // [131]
  virtual HRESULT STDMETHODCALLTYPE FlashVersion(long* version/*[out,retval]*/) = 0; // [132]
  virtual HRESULT STDMETHODCALLTYPE get_WMode(BSTR* pVal/*[out,retval]*/) = 0; // [133]
  virtual HRESULT STDMETHODCALLTYPE set_WMode(BSTR pVal/*[in]*/) = 0; // [133]
  virtual HRESULT STDMETHODCALLTYPE get_SAlign(BSTR* pVal/*[out,retval]*/) = 0; // [134]
  virtual HRESULT STDMETHODCALLTYPE set_SAlign(BSTR pVal/*[in]*/) = 0; // [134]
  virtual HRESULT STDMETHODCALLTYPE get_Menu(VARIANT_BOOL* pVal/*[out,retval]*/) = 0; // [135]
  virtual HRESULT STDMETHODCALLTYPE set_Menu(VARIANT_BOOL pVal/*[in]*/) = 0; // [135]
  virtual HRESULT STDMETHODCALLTYPE get_Base(BSTR* pVal/*[out,retval]*/) = 0; // [136]
  virtual HRESULT STDMETHODCALLTYPE set_Base(BSTR pVal/*[in]*/) = 0; // [136]
  virtual HRESULT STDMETHODCALLTYPE get_scale(BSTR* pVal/*[out,retval]*/) = 0; // [137]
  virtual HRESULT STDMETHODCALLTYPE set_scale(BSTR pVal/*[in]*/) = 0; // [137]
  virtual HRESULT STDMETHODCALLTYPE get_DeviceFont(VARIANT_BOOL* pVal/*[out,retval]*/) = 0; // [138]
  virtual HRESULT STDMETHODCALLTYPE set_DeviceFont(VARIANT_BOOL pVal/*[in]*/) = 0; // [138]
  virtual HRESULT STDMETHODCALLTYPE get_EmbedMovie(VARIANT_BOOL* pVal/*[out,retval]*/) = 0; // [139]
  virtual HRESULT STDMETHODCALLTYPE set_EmbedMovie(VARIANT_BOOL pVal/*[in]*/) = 0; // [139]
  virtual HRESULT STDMETHODCALLTYPE get_BGColor(BSTR* pVal/*[out,retval]*/) = 0; // [140]
  virtual HRESULT STDMETHODCALLTYPE set_BGColor(BSTR pVal/*[in]*/) = 0; // [140]
  virtual HRESULT STDMETHODCALLTYPE get_Quality2(BSTR* pVal/*[out,retval]*/) = 0; // [141]
  virtual HRESULT STDMETHODCALLTYPE set_Quality2(BSTR pVal/*[in]*/) = 0; // [141]
};

// *********************************************************************//
// SmartIntf: TCOMIShockwaveFlash
// Interface: IShockwaveFlash
// *********************************************************************//
class TCOMIShockwaveFlash : public TComInterface<IShockwaveFlash>
{
public:
  TCOMIShockwaveFlash() {}
  TCOMIShockwaveFlash(IShockwaveFlash *intf, bool addRef = false) : TComInterface<IShockwaveFlash>(intf, addRef) {}
};

// *********************************************************************//
// DispIntf:  IShockwaveFlash
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {D27CDB6C-AE6D-11CF-96B8-444553540000}
// *********************************************************************//
class IShockwaveFlashDisp : public TAutoDriver<IShockwaveFlash>
{
  typedef TDispId<IShockwaveFlash> _TDispID;
public:

  IShockwaveFlashDisp()
  {}

  IShockwaveFlashDisp& operator=(IShockwaveFlash *pintf)
  {
    TAutoDriver<IShockwaveFlash>::Bind(pintf);
  }

  HRESULT BindDefault(/*Binds to CoClass ShockwaveFlash*/)
  {
    return OLECHECK(Bind(CLSID_ShockwaveFlash));
  }

  HRESULT /*[VT_HRESULT:0]*/  get_ReadyState(long* thestate/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("ReadyState"), DISPID(-525));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(thestate /*[VT_I4:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  long get_ReadyState(void)
  {
    long thestate;
    get_ReadyState(&thestate);
    return thestate;
  }

  HRESULT /*[VT_HRESULT:0]*/  get_TotalFrames(long* numframes/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("TotalFrames"), DISPID(124));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(numframes /*[VT_I4:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  long get_TotalFrames(void)
  {
    long numframes;
    get_TotalFrames(&numframes);
    return numframes;
  }

  HRESULT /*[VT_HRESULT:0]*/  get_Playing(VARIANT_BOOL* Playing/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Playing"), DISPID(125));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(Playing /*[VT_BOOL:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  VARIANT_BOOL get_Playing(void)
  {
    VARIANT_BOOL Playing;
    get_Playing(&Playing);
    return Playing;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_Playing(VARIANT_BOOL Playing/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Playing"), DISPID(125));
    TAutoArgs<1> _args;
    _args[1] = Playing /*[VT_BOOL:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_Quality(int* Quality/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Quality"), DISPID(105));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(Quality /*[VT_INT:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  int get_Quality(void)
  {
    int Quality;
    get_Quality(&Quality);
    return Quality;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_Quality(int Quality/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Quality"), DISPID(105));
    TAutoArgs<1> _args;
    _args[1] = Quality /*[VT_INT:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_ScaleMode(int* scale/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("ScaleMode"), DISPID(120));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(scale /*[VT_INT:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  int get_ScaleMode(void)
  {
    int scale;
    get_ScaleMode(&scale);
    return scale;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_ScaleMode(int scale/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("ScaleMode"), DISPID(120));
    TAutoArgs<1> _args;
    _args[1] = scale /*[VT_INT:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_AlignMode(int* align/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("AlignMode"), DISPID(121));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(align /*[VT_INT:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  int get_AlignMode(void)
  {
    int align;
    get_AlignMode(&align);
    return align;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_AlignMode(int align/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("AlignMode"), DISPID(121));
    TAutoArgs<1> _args;
    _args[1] = align /*[VT_INT:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_BackgroundColor(long* color/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("BackgroundColor"), DISPID(123));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(color /*[VT_I4:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  long get_BackgroundColor(void)
  {
    long color;
    get_BackgroundColor(&color);
    return color;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_BackgroundColor(long color/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("BackgroundColor"), DISPID(123));
    TAutoArgs<1> _args;
    _args[1] = color /*[VT_I4:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_Loop(VARIANT_BOOL* Loop/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Loop"), DISPID(106));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(Loop /*[VT_BOOL:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  VARIANT_BOOL get_Loop(void)
  {
    VARIANT_BOOL Loop;
    get_Loop(&Loop);
    return Loop;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_Loop(VARIANT_BOOL Loop/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Loop"), DISPID(106));
    TAutoArgs<1> _args;
    _args[1] = Loop /*[VT_BOOL:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_Movie(BSTR* path/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Movie"), DISPID(102));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(path /*[VT_BSTR:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  BSTR get_Movie(void)
  {
    BSTR path;
    get_Movie(&path);
    return path;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_Movie(BSTR path/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Movie"), DISPID(102));
    TAutoArgs<1> _args;
    _args[1] = path /*[VT_BSTR:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_FrameNum(long* FrameNum/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("FrameNum"), DISPID(107));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(FrameNum /*[VT_I4:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  long get_FrameNum(void)
  {
    long FrameNum;
    get_FrameNum(&FrameNum);
    return FrameNum;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_FrameNum(long FrameNum/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("FrameNum"), DISPID(107));
    TAutoArgs<1> _args;
    _args[1] = FrameNum /*[VT_I4:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  SetZoomRect(long left/*[in]*/,long top/*[in]*/,long right/*[in]*/,
                                          long bottom/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("SetZoomRect"), DISPID(109));
    TAutoArgs<4> _args;
    _args[1] = left /*[VT_I4:0]*/;
    _args[2] = top /*[VT_I4:0]*/;
    _args[3] = right /*[VT_I4:0]*/;
    _args[4] = bottom /*[VT_I4:0]*/;
    return OleFunction(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  Zoom(int factor/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Zoom"), DISPID(118));
    TAutoArgs<1> _args;
    _args[1] = factor /*[VT_INT:0]*/;
    return OleFunction(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  Pan(long x/*[in]*/,long y/*[in]*/,int mode/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Pan"), DISPID(119));
    TAutoArgs<3> _args;
    _args[1] = x /*[VT_I4:0]*/;
    _args[2] = y /*[VT_I4:0]*/;
    _args[3] = mode /*[VT_INT:0]*/;
    return OleFunction(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  Play()
  {
    static _TDispID _dispid(*this, OLETEXT("Play"), DISPID(112));
    return OleFunction(_dispid);
  }

  HRESULT /*[VT_HRESULT:0]*/  Stop()
  {
    static _TDispID _dispid(*this, OLETEXT("Stop"), DISPID(113));
    return OleFunction(_dispid);
  }

  HRESULT /*[VT_HRESULT:0]*/  Back()
  {
    static _TDispID _dispid(*this, OLETEXT("Back"), DISPID(114));
    return OleFunction(_dispid);
  }

  HRESULT /*[VT_HRESULT:0]*/  Forward()
  {
    static _TDispID _dispid(*this, OLETEXT("Forward"), DISPID(115));
    return OleFunction(_dispid);
  }

  HRESULT /*[VT_HRESULT:0]*/  Rewind()
  {
    static _TDispID _dispid(*this, OLETEXT("Rewind"), DISPID(116));
    return OleFunction(_dispid);
  }

  HRESULT /*[VT_HRESULT:0]*/  StopPlay()
  {
    static _TDispID _dispid(*this, OLETEXT("StopPlay"), DISPID(126));
    return OleFunction(_dispid);
  }

  HRESULT /*[VT_HRESULT:0]*/  GotoFrame(long FrameNum/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("GotoFrame"), DISPID(127));
    TAutoArgs<1> _args;
    _args[1] = FrameNum /*[VT_I4:0]*/;
    return OleFunction(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  CurrentFrame(long* FrameNum/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("CurrentFrame"), DISPID(128));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(FrameNum /*[VT_I4:1]*/, _args, OleFunction(_dispid, _args));
  }

  HRESULT /*[VT_HRESULT:0]*/  IsPlaying(VARIANT_BOOL* Playing/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("IsPlaying"), DISPID(129));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(Playing /*[VT_BOOL:1]*/, _args, OleFunction(_dispid, _args));
  }

  HRESULT /*[VT_HRESULT:0]*/  PercentLoaded(long* __MIDL_0016/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("PercentLoaded"), DISPID(130));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(__MIDL_0016 /*[VT_I4:1]*/, _args, OleFunction(_dispid, _args));
  }

  HRESULT /*[VT_HRESULT:0]*/  FrameLoaded(long FrameNum/*[in]*/,VARIANT_BOOL* loaded/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("FrameLoaded"), DISPID(131));
    TAutoArgs<1> _args;
    _args[1] = FrameNum /*[VT_I4:0]*/;
    return OutRetValSetterPtr(loaded /*[VT_BOOL:1]*/, _args, OleFunction(_dispid, _args));
  }

  HRESULT /*[VT_HRESULT:0]*/  FlashVersion(long* version/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("FlashVersion"), DISPID(132));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(version /*[VT_I4:1]*/, _args, OleFunction(_dispid, _args));
  }

  HRESULT /*[VT_HRESULT:0]*/  get_WMode(BSTR* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("WMode"), DISPID(133));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BSTR:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  BSTR get_WMode(void)
  {
    BSTR pVal;
    get_WMode(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_WMode(BSTR pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("WMode"), DISPID(133));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BSTR:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_SAlign(BSTR* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("SAlign"), DISPID(134));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BSTR:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  BSTR get_SAlign(void)
  {
    BSTR pVal;
    get_SAlign(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_SAlign(BSTR pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("SAlign"), DISPID(134));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BSTR:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_Menu(VARIANT_BOOL* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Menu"), DISPID(135));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BOOL:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  VARIANT_BOOL get_Menu(void)
  {
    VARIANT_BOOL pVal;
    get_Menu(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_Menu(VARIANT_BOOL pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Menu"), DISPID(135));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BOOL:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_Base(BSTR* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Base"), DISPID(136));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BSTR:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  BSTR get_Base(void)
  {
    BSTR pVal;
    get_Base(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_Base(BSTR pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Base"), DISPID(136));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BSTR:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_scale(BSTR* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("scale"), DISPID(137));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BSTR:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  BSTR get_scale(void)
  {
    BSTR pVal;
    get_scale(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_scale(BSTR pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("scale"), DISPID(137));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BSTR:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_DeviceFont(VARIANT_BOOL* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("DeviceFont"), DISPID(138));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BOOL:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  VARIANT_BOOL get_DeviceFont(void)
  {
    VARIANT_BOOL pVal;
    get_DeviceFont(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_DeviceFont(VARIANT_BOOL pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("DeviceFont"), DISPID(138));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BOOL:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_EmbedMovie(VARIANT_BOOL* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("EmbedMovie"), DISPID(139));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BOOL:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  VARIANT_BOOL get_EmbedMovie(void)
  {
    VARIANT_BOOL pVal;
    get_EmbedMovie(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_EmbedMovie(VARIANT_BOOL pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("EmbedMovie"), DISPID(139));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BOOL:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_BGColor(BSTR* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("BGColor"), DISPID(140));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BSTR:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  BSTR get_BGColor(void)
  {
    BSTR pVal;
    get_BGColor(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_BGColor(BSTR pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("BGColor"), DISPID(140));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BSTR:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  HRESULT /*[VT_HRESULT:0]*/  get_Quality2(BSTR* pVal/*[out,retval]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Quality2"), DISPID(141));
    TAutoArgs<0> _args;
    return OutRetValSetterPtr(pVal /*[VT_BSTR:1]*/, _args, OlePropertyGet(_dispid, _args));
  }

  BSTR get_Quality2(void)
  {
    BSTR pVal;
    get_Quality2(&pVal);
    return pVal;
  }

  HRESULT /*[VT_HRESULT:0]*/  set_Quality2(BSTR pVal/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("Quality2"), DISPID(141));
    TAutoArgs<1> _args;
    _args[1] = pVal /*[VT_BSTR:0]*/;
    return OlePropertyPut(_dispid, _args);
  }

  __property long ReadyState = {read = get_ReadyState};
  __property long TotalFrames = {read = get_TotalFrames};
  __property VARIANT_BOOL Playing = {read = get_Playing, write = set_Playing};
  __property int Quality = {read = get_Quality, write = set_Quality};
  __property int ScaleMode = {read = get_ScaleMode, write = set_ScaleMode};
  __property int AlignMode = {read = get_AlignMode, write = set_AlignMode};
  __property long BackgroundColor = {read = get_BackgroundColor, write = set_BackgroundColor};
  __property VARIANT_BOOL Loop = {read = get_Loop, write = set_Loop};
  __property BSTR Movie = {read = get_Movie, write = set_Movie};
  __property long FrameNum = {read = get_FrameNum, write = set_FrameNum};
  __property BSTR WMode = {read = get_WMode, write = set_WMode};
  __property BSTR SAlign = {read = get_SAlign, write = set_SAlign};
  __property VARIANT_BOOL Menu = {read = get_Menu, write = set_Menu};
  __property BSTR Base = {read = get_Base, write = set_Base};
  __property BSTR scale = {read = get_scale, write = set_scale};
  __property VARIANT_BOOL DeviceFont = {read = get_DeviceFont, write = set_DeviceFont};
  __property VARIANT_BOOL EmbedMovie = {read = get_EmbedMovie, write = set_EmbedMovie};
  __property BSTR BGColor = {read = get_BGColor, write = set_BGColor};
  __property BSTR Quality2 = {read = get_Quality2, write = set_Quality2};
};

// *********************************************************************//
// Interface: DShockwaveFlashEvents
// Flags:     (4112) Hidden Dispatchable
// GUID:      {D27CDB6D-AE6D-11CF-96B8-444553540000}
// *********************************************************************//
interface DShockwaveFlashEvents : public IDispatch
{
// DispInterfaces have no methods. Their methods and properties are
// accessed via IDispatch::Invoke. See the class DShockwaveFlashEventsDisp provided
// below for an easy way to access the methods/properties of this
// interface.
};
// *********************************************************************//
// DispIntf:  DShockwaveFlashEvents
// Flags:     (4112) Hidden Dispatchable
// GUID:      {D27CDB6D-AE6D-11CF-96B8-444553540000}
// *********************************************************************//
class DShockwaveFlashEventsDisp : public TAutoDriver<DShockwaveFlashEvents>
{
  typedef TDispId<DShockwaveFlashEvents> _TDispID;
public:

  DShockwaveFlashEventsDisp()
  {}

  DShockwaveFlashEventsDisp& operator=(DShockwaveFlashEvents *pintf)
  {
    TAutoDriver<DShockwaveFlashEvents>::Bind(pintf);
  }

  void /*[VT_VOID:0]*/  OnReadyStateChange(long newState)
  {
    static _TDispID _dispid(*this, OLETEXT("OnReadyStateChange"), DISPID(-609));
    TAutoArgs<1> _args;
    _args[1] = newState /*[VT_I4:0]*/;
    OleProcedure(_dispid, _args);
  }

  void /*[VT_VOID:0]*/  OnProgress(long percentDone)
  {
    static _TDispID _dispid(*this, OLETEXT("OnProgress"), DISPID(1958));
    TAutoArgs<1> _args;
    _args[1] = percentDone /*[VT_I4:0]*/;
    OleProcedure(_dispid, _args);
  }

  void /*[VT_VOID:0]*/  FSCommand(BSTR command/*[in]*/,BSTR args/*[in]*/)
  {
    static _TDispID _dispid(*this, OLETEXT("FSCommand"), DISPID(150));
    TAutoArgs<2> _args;
    _args[1] = command /*[VT_BSTR:0]*/;
    _args[2] = args /*[VT_BSTR:0]*/;
    OleProcedure(_dispid, _args);
  }

};


// *********************************************************************//
// OCX PROXY CLASS DECLARATION
// Control Name     : TShockwaveFlashProxy
// Help String      : Shockwave Flash
// Default Interface: IShockwaveFlash
// Def. Intf. Object: TCOMIShockwaveFlash
// Def. Intf. DISP? : No
// Event   Interface: DShockwaveFlashEvents
// *********************************************************************//

// *********************************************************************//
// Definition of closures to allow VCL handlers to catch OCX events.    //
// *********************************************************************//
typedef void __fastcall (__closure * TShockwaveFlashProxyOnReadyStateChange)(System::TObject * Sender, long newState);
typedef void __fastcall (__closure * TShockwaveFlashProxyOnProgress)(System::TObject * Sender, long percentDone);
typedef void __fastcall (__closure * TShockwaveFlashProxyFSCommand)(System::TObject * Sender, BSTR command/*[in]*/, 
                                                                                              BSTR args/*[in]*/);

//+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
// Proxy class to host Shockwave Flash in CBuilder IDE/Applications.
//-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
class PACKAGE TShockwaveFlashProxy : public TOCXProxy
{
private:

  // Instance of Closures to expose OCX Events as VCL ones
  //
  TShockwaveFlashProxyOnReadyStateChange FOnReadyStateChange;
  TShockwaveFlashProxyOnProgress FOnProgress;
  TShockwaveFlashProxyFSCommand FOnFSCommand;

  // Default Interace of OCX
  //
  TCOMIShockwaveFlash m_OCXIntf;
  // VCL Property Getters/Setters which delegate to OCX
  //

  // Static variables used by all instances of OCX proxy
  //
  static int          EventDispIDs[3];
  static TControlData CControlData;

  // Method providing access to interface as __property 
  //
  TCOMIShockwaveFlash __fastcall GetControlInterface(void);

protected:
  void     __fastcall CreateControl  (void);
  void     __fastcall InitControlData(void);

public:
  virtual  __fastcall TShockwaveFlashProxy(TComponent* AOwner) : TOCXProxy(AOwner)
  {};
  virtual  __fastcall TShockwaveFlashProxy(HWND        Parent) : TOCXProxy(Parent)
  {};

  // OCX methods
  //
  void/*HRESULT*/ __fastcall SetZoomRect(long left/*[in]*/, long top/*[in]*/, long right/*[in]*/, 
                                         long bottom/*[in]*/);
  void/*HRESULT*/ __fastcall Zoom(int factor/*[in]*/);
  void/*HRESULT*/ __fastcall Pan(long x/*[in]*/, long y/*[in]*/, int mode/*[in]*/);
  void/*HRESULT*/ __fastcall Play(void);
  void/*HRESULT*/ __fastcall Stop(void);
  void/*HRESULT*/ __fastcall Back(void);
  void/*HRESULT*/ __fastcall Forward(void);
  void/*HRESULT*/ __fastcall Rewind(void);
  void/*HRESULT*/ __fastcall StopPlay(void);
  void/*HRESULT*/ __fastcall GotoFrame(long FrameNum/*[in]*/);
  long __fastcall CurrentFrame(void);
  VARIANT_BOOL __fastcall IsPlaying(void);
  long __fastcall PercentLoaded(void);
  VARIANT_BOOL __fastcall FrameLoaded(long FrameNum/*[in]*/);
  long __fastcall FlashVersion(void);

  // OCX properties
  //
  __property int ReadyState={ read=GetIntegerProp, index=-525 };
  __property int TotalFrames={ read=GetIntegerProp, index=124 };
  __property TCOMIShockwaveFlash ControlInterface={ read=GetControlInterface };

  // Published properties
  //
__published:

  // Standard properties
  //
  __property TabStop;
  __property Align;
  __property DragCursor;
  __property DragMode;
  __property ParentShowHint;
  __property PopupMenu;
  __property ShowHint;
  __property TabOrder;
  __property Visible;
  __property OnDragDrop;
  __property OnDragOver;
  __property OnEndDrag;
  __property OnEnter;
  __property OnExit;
  __property OnStartDrag;

  // OCX properties
  //
  __property Word Playing={ read=GetWordBoolProp, write=SetWordBoolProp, stored=false, index=125 };
  __property int Quality={ read=GetIntegerProp, write=SetIntegerProp, stored=false, index=105 };
  __property int ScaleMode={ read=GetIntegerProp, write=SetIntegerProp, stored=false, index=120 };
  __property int AlignMode={ read=GetIntegerProp, write=SetIntegerProp, stored=false, index=121 };
  __property int BackgroundColor={ read=GetIntegerProp, write=SetIntegerProp, stored=false, index=123 };
  __property Word Loop={ read=GetWordBoolProp, write=SetWordBoolProp, stored=false, index=106 };
  __property System::WideString Movie={ read=GetWideStringProp, write=SetWideStringProp, stored=false, index=102 };
  __property int FrameNum={ read=GetIntegerProp, write=SetIntegerProp, stored=false, index=107 };
  __property System::WideString WMode={ read=GetWideStringProp, write=SetWideStringProp, stored=false, index=133 };
  __property System::WideString SAlign={ read=GetWideStringProp, write=SetWideStringProp, stored=false, index=134 };
  __property Word Menu={ read=GetWordBoolProp, write=SetWordBoolProp, stored=false, index=135 };
  __property System::WideString Base={ read=GetWideStringProp, write=SetWideStringProp, stored=false, index=136 };
  __property System::WideString scale={ read=GetWideStringProp, write=SetWideStringProp, stored=false, index=137 };
  __property Word DeviceFont={ read=GetWordBoolProp, write=SetWordBoolProp, stored=false, index=138 };
  __property Word EmbedMovie={ read=GetWordBoolProp, write=SetWordBoolProp, stored=false, index=139 };
  __property System::WideString BGColor={ read=GetWideStringProp, write=SetWideStringProp, stored=false, index=140 };
  __property System::WideString Quality2={ read=GetWideStringProp, write=SetWideStringProp, stored=false, index=141 };

  // OCX Events
  //
  __property TShockwaveFlashProxyOnReadyStateChange OnReadyStateChange={ read=FOnReadyStateChange, write=FOnReadyStateChange };
  __property TShockwaveFlashProxyOnProgress OnProgress={ read=FOnProgress, write=FOnProgress };
  __property TShockwaveFlashProxyFSCommand OnFSCommand={ read=FOnFSCommand, write=FOnFSCommand };
};


// *********************************************************************//
// COCLASS DEFAULT INTERFACE CREATOR
// CoClass  : FlashProp
// Interface: TCOMIUnknown
// *********************************************************************//
class CoFlashProp : public CoClassCreator
{
public:
  static TCOMIUnknown Create(void);
  static TCOMIUnknown CreateRemote(LPWSTR machineName);

  static HRESULT Create(TCOMIUnknown& defIntfObj);
  static HRESULT CreateRemote(LPWSTR machineName, TCOMIUnknown& defIntfObj);
};

#if defined(USING_ATL) || defined(USING_ATLVCL)

// *********************************************************************//
// CONNECTIONPOINT/EVENT PROXY
// CoClass         : ShockwaveFlash
// Event Interface : DShockwaveFlashEvents
// *********************************************************************//
template <class T>
class TEvents_ShockwaveFlash : public IConnectionPointImpl<T, &DIID_DShockwaveFlashEvents, CComUnkArray<CONNECTIONPOINT_ARRAY_SIZE> >
{
public:
  void Fire_OnReadyStateChange(long newState)
  {
    VARIANTARG * pvars = new VARIANTARG[1];
    for (int i = 0; i < 1; i++)
      VariantInit(&pvars[i]);
    T * pT = (T*)this;
    pT->Lock();
    IUnknown ** pp = m_vec.begin();
    while (pp < m_vec.end())
    {
      if (*pp != NULL)
      {
        pvars[0].vt = VT_I4;
        pvars[0].lVal = newState;
        DISPPARAMS disp = { pvars, NULL, 1, 0 };
        IDispatch * pDispatch = reinterpret_cast<IDispatch*>(*pp);
        pDispatch->Invoke(0xFFFFFD9F, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
      }
      pp++;
    }
    pT->Unlock();
    delete[] pvars;
  }

  void Fire_OnProgress(long percentDone)
  {
    VARIANTARG * pvars = new VARIANTARG[1];
    for (int i = 0; i < 1; i++)
      VariantInit(&pvars[i]);
    T * pT = (T*)this;
    pT->Lock();
    IUnknown ** pp = m_vec.begin();
    while (pp < m_vec.end())
    {
      if (*pp != NULL)
      {
        pvars[0].vt = VT_I4;
        pvars[0].lVal = percentDone;
        DISPPARAMS disp = { pvars, NULL, 1, 0 };
        IDispatch * pDispatch = reinterpret_cast<IDispatch*>(*pp);
        pDispatch->Invoke(0x7A6, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
      }
      pp++;
    }
    pT->Unlock();
    delete[] pvars;
  }

  void Fire_FSCommand(BSTR command/*[in]*/, BSTR args/*[in]*/)
  {
    VARIANTARG * pvars = new VARIANTARG[2];
    for (int i = 0; i < 2; i++)
      VariantInit(&pvars[i]);
    T * pT = (T*)this;
    pT->Lock();
    IUnknown ** pp = m_vec.begin();
    while (pp < m_vec.end())
    {
      if (*pp != NULL)
      {
        pvars[1].vt = VT_BSTR;
        pvars[1].bstrVal = args;
        pvars[0].vt = VT_BSTR;
        pvars[0].bstrVal = command;
        DISPPARAMS disp = { pvars, NULL, 2, 0 };
        IDispatch * pDispatch = reinterpret_cast<IDispatch*>(*pp);
        pDispatch->Invoke(0x96, IID_NULL, LOCALE_USER_DEFAULT, DISPATCH_METHOD, &disp, NULL, NULL, NULL);
      }
      pp++;
    }
    pT->Unlock();
    delete[] pvars;
  }

};


#endif // USING_ATL || USING_ATLVCL

};     // namespace Shockwaveflashobjects_tlb

#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using  namespace Shockwaveflashobjects_tlb;
#endif

#pragma option pop

#endif // __ShockwaveFlashObjects_TLB_h__
